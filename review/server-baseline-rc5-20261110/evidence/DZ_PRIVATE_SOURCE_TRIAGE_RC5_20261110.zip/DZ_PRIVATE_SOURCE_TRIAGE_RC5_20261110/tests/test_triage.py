import hashlib
import json
import tempfile
from pathlib import Path
import unittest
from triage_readonly import audit, match_lines, category, valid_relative, asset_group


def sha(b):return hashlib.sha256(b).hexdigest()

class AuditTests(unittest.TestCase):
    def fixture(self, root):
        stage=root/'stage';stage.mkdir()
        c=stage/'PRIVATE_CANDIDATE_NOT_FOR_PUBLIC_PUSH';c.mkdir()
        (c/'app/Services/GardnerCommerce').mkdir(parents=True)
        (c/'resources/gardner/illustrations').mkdir(parents=True)
        text=b'<?php\n$email="parent@example.test";\n$key="ghp_abcdefghijklmnop1234567890";\n'
        image=b'FAKEPNG'
        a=c/'app/Services/GardnerCommerce/Orders.php';a.write_bytes(text)
        b=c/'resources/gardner/illustrations/icon.webp';b.write_bytes(image)
        info=[{'source_path':'site/app/Services/GardnerCommerce/Orders.php','destination_path':'app/Services/GardnerCommerce/Orders.php','sha256':sha(text)},
              {'source_path':'site/resources/gardner/illustrations/icon.webp','destination_path':'resources/gardner/illustrations/icon.webp','sha256':sha(image)}]
        risk=[{'path':info[0]['source_path'],'sha256':sha(text),'codes':['HISTORIC_PAID_CUSTOMER_OVERRIDE_REVIEW','EMAIL_ADDRESS_IN_SOURCE']},
              {'path':info[1]['source_path'],'sha256':sha(image),'codes':['ASSET_LICENSE_OR_PROVENANCE_REVIEW']}]
        (stage/'STAGE_RESULT.json').write_text(json.dumps({'event':'DZ_PRIVATE_STAGING_COMPLETE','public_push_authorized':False,'source_files_scanned':2,'generated_files_omitted':0,'private_candidate_files':2,'flagged_files_count':2}))
        (stage/'PRIVATE_STAGE_MANIFEST.json').write_text(json.dumps({'schema':'dz-private-source-stage-v1','included':info}))
        (stage/'PRIVATE_STAGE_RISK_REVIEW.json').write_text(json.dumps({'schema':'dz-private-source-risks-v1','security_gate':'HOLD_REVIEW_NOT_AUTO_APPROVED','public_push_authorized':False,'files_requiring_manual_review':risk}))
        return stage,a

    def test_masking_counts_only(self):
        b=b'a=x@example.test\nmy_sk="ghp_abcdefghijklmnop1234567890"'
        v=match_lines(b)
        self.assertIn('EMAIL_ADDRESS_IN_SOURCE',v)
        self.assertIn('POTENTIAL_API_TOKEN',v)
        self.assertNotIn('example.test',str(v))
        self.assertEqual(v['EMAIL_ADDRESS_IN_SOURCE']['line_numbers'],[1])
    def test_relative(self):
        self.assertTrue(valid_relative('site/app/example.php'))
        for s in ['../.env','a//b','/etc/passwd','a/../b','a\\b']:
            self.assertFalse(valid_relative(s),s)
    def test_risk_priority(self):
        self.assertEqual(category('site/app/Services/GardnerCommerce/Orders.php',['HISTORIC_PAID_CUSTOMER_OVERRIDE_REVIEW']),'P0_CUSTOMER_PAYMENT_COMPATIBILITY')
    def test_asset_group(self):
        self.assertEqual(asset_group('site/public/images/homepage.png'),'site-public-images')
    def test_good_fixture_no_export(self):
        with tempfile.TemporaryDirectory() as t:
            r=Path(t);stage,_=self.fixture(r);out=r/'output'
            x=audit(stage,out,exact_counts=False,require_root=False)
            self.assertEqual(x['flagged'],2)
            report=json.loads((out/'DZ_SOURCE_TRIAGE_REDACTED.json').read_text())
            self.assertFalse(report['permission_to_push_public'])
            self.assertNotIn('parent@example.test',(out/'DZ_SOURCE_TRIAGE_REDACTED.json').read_text())
            self.assertNotIn('ghp_',(out/'DZ_SOURCE_TRIAGE_REDACTED.json').read_text())
            self.assertEqual(report['asset_folder_counts']['gardner-icons'],1)
    def test_mutated_file_rejected(self):
        with tempfile.TemporaryDirectory() as t:
            r=Path(t);stage,source=self.fixture(r);source.write_text('changed')
            with self.assertRaisesRegex(RuntimeError,'SOURCE_SHA256_CHANGED'):
                audit(stage,r/'out',exact_counts=False,require_root=False)
    def test_duplicate_stage_refused(self):
        with tempfile.TemporaryDirectory() as t:
            r=Path(t);stage,_=self.fixture(r);out=r/'out'
            audit(stage,out,exact_counts=False,require_root=False)
            with self.assertRaisesRegex(RuntimeError,'REVIEW_ALREADY_EXISTS'):
                audit(stage,out,exact_counts=False,require_root=False)
    def test_unverified_flag_change_rejected(self):
        with tempfile.TemporaryDirectory() as t:
            r=Path(t);stage,_=self.fixture(r)
            p=stage/'PRIVATE_STAGE_RISK_REVIEW.json';d=json.loads(p.read_text());d['files_requiring_manual_review'][0]['sha256']='0'*64;p.write_text(json.dumps(d))
            with self.assertRaisesRegex(RuntimeError,'RISK_MANIFEST_INVALID'):
                audit(stage,r/'out',exact_counts=False,require_root=False)

if __name__=='__main__':unittest.main()
