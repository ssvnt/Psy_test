#!/usr/bin/env python3
"""Read-only post-stage security triage for Dobry Zhuk.

Only reads an isolated /root candidate; writes anonymized reports to a new /root
folder. No git/network/mail/payment/model calls. Does not certify public release.
"""
from __future__ import annotations

import argparse
from collections import Counter
import hashlib
import json
import os
from pathlib import Path, PurePosixPath
import re

DEFAULT_STAGE = Path('/root/dz-private-github-candidate-20261109')
DEFAULT_OUT = Path('/root/dz-private-source-security-review-20261110')
EXP = {'files': 1266, 'scanned': 1800, 'excluded': 534, 'flagged': 348}

# Exact predicates from stage_private_source.py, and additional *indicators*.
RULES = {
    'UUID_LITERAL': re.compile(rb'\b[0-9a-fA-F]{8}-(?:[0-9a-fA-F]{4}-){3}[0-9a-fA-F]{12}\b'),
    'EMAIL_ADDRESS_IN_SOURCE': re.compile(rb'(?i)\b[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,}\b'),
    'BANK_PAYMENT_LINK_LITERAL': re.compile(rb'(?i)https?://(?:pay\.)?tochka(?:place)?\.com/[^\s"\']+'),
    'PHONE_RU_LIKE': re.compile(rb'(?<!\d)(?:\+7|8)[\s()\-]*9\d{2}[\s()\-]*\d{3}[\s()\-]*\d{2}[\s()\-]*\d{2}(?!\d)'),
    'POTENTIAL_API_TOKEN': re.compile(rb'\b(?:github_pat_|gh[opusr]_|AKIA|ASIA|sk_live_|rk_live_|xox[baprs]-)[A-Za-z0-9_-]{16,}\b'),
    'PEM_PRIVATE_KEY': re.compile(rb'-----BEGIN (?:RSA |EC |OPENSSH |ENCRYPTED )?PRIVATE KEY-----'),
    'POTENTIAL_EMBEDDED_CREDENTIAL': re.compile(rb'(?i)\b(?:client[_-]?secret|api[_-]?key|access[_-]?token|password|private[_-]?key)\b\s*(?:=>|:|=)\s*["\'](?!example|test|placeholder|changeme|fake|dummy|\$|\{)[^"\'\r\n]{8,}["\']'),
}
ASSET_EXTENSIONS = {'.png', '.jpg', '.jpeg', '.webp', '.gif', '.ico', '.woff', '.woff2', '.ttf', '.otf', '.mp3', '.mp4', '.pdf', '.svg'}
TEXT_EXTENSIONS = {'.php', '.vue', '.ts', '.js', '.json', '.md', '.txt', '.py', '.sh', '.mjs', '.css', '.scss', '.html', '.htm', '.xml', '.sql', '.yaml', '.yml', '.toml', '.ini', '.lock', '.cjs', '.conf'}


def digest(path: Path) -> str:
    h = hashlib.sha256()
    with path.open('rb') as f:
        for part in iter(lambda: f.read(1024 * 1024), b''):
            h.update(part)
    return h.hexdigest()


def valid_relative(s: str) -> bool:
    if not s or '\\' in s or '\x00' in s:
        return False
    p = PurePosixPath(s)
    return not p.is_absolute() and all(piece not in ('', '.', '..') for piece in s.split('/'))


def category(path: str, codes: list[str]) -> str:
    if 'HISTORIC_PAID_CUSTOMER_OVERRIDE_REVIEW' in codes:
        return 'P0_CUSTOMER_PAYMENT_COMPATIBILITY'
    if path == 'site/config/gardner_commerce.php':
        return 'P0_PAYMENT_CONFIGURATION'
    if path == 'site/app/Services/TeenReportReleaseGate.php':
        return 'P1_REPORT_RELEASE_GATE'
    if 'BANK_PAYMENT_LINK_LITERAL' in codes:
        return 'P1_BANK_LINK_REVIEW'
    if 'ASSET_LICENSE_OR_PROVENANCE_REVIEW' in codes:
        return 'P2_ASSET_PROVENANCE'
    if path.startswith('site/tests/') or '/fixtures/' in path or path.startswith('site/tools/'):
        return 'P2_TEST_OR_QA_DATA'
    if path.startswith('site/database/data/legal/'):
        return 'P2_LEGAL_PUBLIC_CONTACT'
    if path.startswith('site/app/Mail/') or path.startswith('site/config/mail.php'):
        return 'P2_MAIL_CONTACT'
    if path.startswith('site/resources/'):
        return 'P2_FRONTEND_OR_CONTENT'
    return 'P2_OTHER_SOURCE_LITERAL'


def asset_group(path: str) -> str:
    if path.startswith('site/public/images/'):
        return 'site-public-images'
    if path.startswith('site/resources/gardner/illustrations/'):
        return 'gardner-icons'
    if path.startswith('site/public/dz-guides-v1/'):
        return 'site-guides'
    if path.startswith('site/public/favicons/'):
        return 'favicons'
    if path.startswith('opt/'):
        return 'orchestrator-assets'
    return 'other-assets'


def match_lines(data: bytes) -> dict[str, dict]:
    # Only numbers of matches and line numbers; NEVER include match text or snippets.
    hits = {}
    for name, regex in RULES.items():
        found = list(regex.finditer(data))
        if found:
            hits[name] = {
                'count': len(found),
                'line_numbers': sorted({data.count(b'\n', 0, m.start()) + 1 for m in found})[:40],
                'line_numbers_truncated': len({data.count(b'\n', 0, m.start()) + 1 for m in found}) > 40,
            }
    return hits


def audit(stage: Path, out: Path, *, exact_counts: bool = True, require_root: bool = True) -> dict:
    stage = stage.resolve(strict=True)
    candidate = (stage / 'PRIVATE_CANDIDATE_NOT_FOR_PUBLIC_PUSH').resolve(strict=True)
    if candidate.parent != stage:
        raise RuntimeError('CANDIDATE_OUTSIDE_STAGE')
    results = json.loads((stage / 'STAGE_RESULT.json').read_text('utf-8'))
    manifest = json.loads((stage / 'PRIVATE_STAGE_MANIFEST.json').read_text('utf-8'))
    risks = json.loads((stage / 'PRIVATE_STAGE_RISK_REVIEW.json').read_text('utf-8'))
    included = manifest.get('included')
    flagged = risks.get('files_requiring_manual_review')
    if (results.get('event') != 'DZ_PRIVATE_STAGING_COMPLETE' or
        results.get('public_push_authorized') is not False or
        risks.get('security_gate') != 'HOLD_REVIEW_NOT_AUTO_APPROVED' or
        risks.get('public_push_authorized') is not False or
        manifest.get('schema') != 'dz-private-source-stage-v1' or
        risks.get('schema') != 'dz-private-source-risks-v1' or
        not isinstance(included, list) or not isinstance(flagged, list)):
        raise RuntimeError('STAGE_PROVENANCE_INVALID')
    if exact_counts and (len(included) != EXP['files'] or len(flagged) != EXP['flagged'] or
                        results.get('source_files_scanned') != EXP['scanned'] or
                        results.get('generated_files_omitted') != EXP['excluded']):
        raise RuntimeError('STAGE_COUNTS_CHANGED')
    if results.get('private_candidate_files') != len(included) or results.get('flagged_files_count') != len(flagged):
        raise RuntimeError('STAGE_COUNT_INCONSISTENCY')
    if require_root and (out.parent.resolve(strict=True) != Path('/root') or not str(stage).startswith('/root/')):
        raise RuntimeError('PRIVATE_ROOT_ONLY')
    if out.exists() or out.is_symlink():
        raise RuntimeError('REVIEW_ALREADY_EXISTS_DO_NOT_OVERWRITE')
    imap = {}
    seen_dest = set()
    for f in included:
        src, dest, sha = f.get('source_path'), f.get('destination_path'), f.get('sha256')
        if (not isinstance(src, str) or not isinstance(dest, str) or
            not valid_relative(src) or not valid_relative(dest) or
            not (src.startswith('site/') or src.startswith('opt/')) or
            not isinstance(sha, str) or not re.fullmatch(r'[a-f0-9]{64}', sha) or
            src in imap or dest in seen_dest):
            raise RuntimeError('INCLUDED_MANIFEST_INVALID')
        imap[src] = f
        seen_dest.add(dest)
    fmap = {}
    for f in flagged:
        src, sha, codes = f.get('path'), f.get('sha256'), f.get('codes')
        if (not isinstance(src, str) or src not in imap or src in fmap or
            not isinstance(codes, list) or not codes or
            sha != imap[src]['sha256']):
            raise RuntimeError('RISK_MANIFEST_INVALID')
        fmap[src] = codes
    reviewed_files = []
    all_code_counter = Counter()
    category_counts = Counter()
    asset_counts = Counter()
    unflagged_extra = []
    for src, row in sorted(imap.items()):
        dest = candidate / row['destination_path']
        if dest.is_symlink() or not dest.is_file() or not dest.resolve(strict=True).is_relative_to(candidate):
            raise RuntimeError('SOURCE_PATH_INVALID_OR_SYMLINK')
        if digest(dest) != row['sha256']:
            raise RuntimeError('SOURCE_SHA256_CHANGED')
        codes = fmap.get(src, [])
        is_asset = dest.suffix.lower() in ASSET_EXTENSIONS
        if is_asset:
            hits = {}
        elif dest.suffix.lower() in TEXT_EXTENSIONS or '.' not in dest.name:
            hits = match_lines(dest.read_bytes())
        else:
            hits = {}
        if codes:
            kind = category(src, codes)
            category_counts[kind] += 1
            if is_asset:
                asset_counts[asset_group(src)] += 1
            reviewed_files.append({
                'path': src, 'category': kind, 'original_audit_flags': codes,
                'matches_only_counts_and_line_numbers': hits,
                'sha256': row['sha256'],
                'manual_review_required': True,
            })
            for c in codes:
                all_code_counter[c] += 1
        elif any(k in hits for k in ('PEM_PRIVATE_KEY', 'POTENTIAL_API_TOKEN', 'POTENTIAL_EMBEDDED_CREDENTIAL')):
            unflagged_extra.append({'path': src, 'detected_rule_names': sorted(set(hits) & {
                'PEM_PRIVATE_KEY', 'POTENTIAL_API_TOKEN', 'POTENTIAL_EMBEDDED_CREDENTIAL'
            }), 'line_numbers': {k:v['line_numbers'] for k,v in hits.items() if k in {
                'PEM_PRIVATE_KEY', 'POTENTIAL_API_TOKEN', 'POTENTIAL_EMBEDDED_CREDENTIAL'}}})
    if sum(category_counts.values()) != len(fmap):
        raise RuntimeError('TRIAGE_ACCOUNTING_INVALID')
    out.mkdir(mode=0o700)
    report = {
        'schema': 'dz-privacy-preserving-source-triage-v1',
        'status': 'REVIEW_ONLY_PUBLIC_GITHUB_PUSH_FORBIDDEN',
        'source_files_sha256_verified': len(imap),
        'flagged_files_count': len(fmap),
        'unflagged_file_count': len(imap)-len(fmap),
        'original_indicator_file_counts': dict(sorted(all_code_counter.items())),
        'priority_category_file_counts': dict(sorted(category_counts.items())),
        'asset_folder_counts': dict(sorted(asset_counts.items())),
        'unflagged_new_credential_suspicions': unflagged_extra,
        'flagged_files': reviewed_files,
        'credential_values_exported': False,
        'customer_identifiers_exported': False,
        'source_bytes_exported': False,
        'permission_to_push_public': False,
        'production_writes': 0,
        'site_restarts': 0,
        'model_calls': 0,
        'mail_sends': 0,
        'bank_calls': 0,
        'git_pushes': 0,
    }
    dest = out / 'DZ_SOURCE_TRIAGE_REDACTED.json'
    dest.write_text(json.dumps(report, ensure_ascii=False, indent=2)+'\n', encoding='utf-8')
    dest.chmod(0o600)
    summary = (
        'DZ_SOURCE_TRIAGE_READONLY_OK\n'
        'Source SHA256 verified: {}\nFlagged files: {}\nUnflagged (not certified safe): {}\n'
        'New possible credential files: {}\n\n'
        'Critical payment compatibility rules MUST stay active in production.\n'
        'GitHub source push forbidden until review, tests, and license approval.\n'
        'NO CUSTOMER VALUES OR SOURCE EXPORTED\n'
    ).format(len(imap),len(fmap),len(imap)-len(fmap),len(unflagged_extra))
    (out / 'DZ_SOURCE_TRIAGE_SUMMARY.txt').write_text(summary, encoding='utf-8')
    return {'event': 'DZ_SOURCE_TRIAGE_READONLY_OK', 'source_sha256_verified':len(imap),
            'flagged': len(fmap), 'new_possible_credential_files': len(unflagged_extra),
            'report_file': str(dest), 'public_push_authorized':False}


def main():
    os.umask(0o077)
    p=argparse.ArgumentParser()
    p.add_argument('--stage',type=Path,default=DEFAULT_STAGE)
    p.add_argument('--out',type=Path,default=DEFAULT_OUT)
    args=p.parse_args()
    try:
        print(json.dumps(audit(args.stage,args.out),ensure_ascii=False,sort_keys=True))
        return 0
    except Exception as e:
        # Do not print source contents or values; code and exception type only.
        print(json.dumps({'event':'DZ_SOURCE_TRIAGE_BLOCKED','exception_type':type(e).__name__,
                          'code': str(e) if isinstance(e, RuntimeError) else 'INTERNAL_ERROR',
                          'public_push_authorized': False},ensure_ascii=False))
        return 2


if __name__=='__main__':
    raise SystemExit(main())
