#!/usr/bin/env bash
set -Eeuo pipefail
cd "$(dirname "$0")"
PYTHONDONTWRITEBYTECODE=1 PYTHONPATH="$PWD" python3 -B -m unittest discover -s tests -v
